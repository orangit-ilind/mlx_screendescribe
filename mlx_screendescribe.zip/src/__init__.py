"""MLX Screendescribe - Vision-language model inference for time tracking."""

